const pool = require('../config/database');

class DividendsController {
  async list(req, res) {
    try {
      const userId = req.userId;
      const { startDate, endDate, assetId } = req.query;
      
      let query = `
        SELECT d.*, 
               COALESCE(a.ticker, 'N/A') as ticker, 
               COALESCE(a.name, 'Ativo removido') as asset_name, 
               COALESCE(ac.name, 'Sem classe') as class_name, 
               COALESCE(ac.color, '#6b7280') as color
        FROM dividends d
        LEFT JOIN assets a ON d.asset_id = a.id
        LEFT JOIN asset_classes ac ON a.asset_class_id = ac.id
        WHERE d.user_id = $1
      `;
      const params = [userId];

      if (startDate) {
        params.push(startDate);
        query += ` AND d.payment_date >= $${params.length}`;
      }
      if (endDate) {
        params.push(endDate);
        query += ` AND d.payment_date <= $${params.length}`;
      }
      if (assetId) {
        params.push(assetId);
        query += ` AND d.asset_id = $${params.length}`;
      }

      query += ' ORDER BY d.payment_date DESC';
      
      const result = await pool.query(query, params);
      return res.json({ dividends: result.rows });
    } catch (error) {
      console.error('Erro ao listar dividendos:', error);
      return res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }

  async getSummary(req, res) {
    try {
      const userId = req.userId;
      const { year } = req.query;
      const targetYear = (year && !isNaN(parseInt(year))) ? parseInt(year) : new Date().getFullYear();

      const totalYearResult = await pool.query(`
        SELECT COALESCE(SUM(amount), 0) as total
        FROM dividends 
        WHERE user_id = $1 AND EXTRACT(YEAR FROM payment_date) = $2
      `, [userId, targetYear]);

      const thisMonthResult = await pool.query(`
        SELECT COALESCE(SUM(amount), 0) as total
        FROM dividends 
        WHERE user_id = $1 
        AND EXTRACT(YEAR FROM payment_date) = EXTRACT(YEAR FROM CURRENT_DATE)
        AND EXTRACT(MONTH FROM payment_date) = EXTRACT(MONTH FROM CURRENT_DATE)
      `, [userId]);

      const byMonthResult = await pool.query(`
        SELECT TO_CHAR(payment_date, 'YYYY-MM') as month, 
               TO_CHAR(payment_date, 'Mon') as month_name,
               COALESCE(SUM(amount), 0) as total
        FROM dividends 
        WHERE user_id = $1 AND EXTRACT(YEAR FROM payment_date) = $2
        GROUP BY TO_CHAR(payment_date, 'YYYY-MM'), TO_CHAR(payment_date, 'Mon')
        ORDER BY month
      `, [userId, targetYear]);

      const byAssetResult = await pool.query(`
        SELECT COALESCE(a.ticker, 'N/A') as ticker, 
               COALESCE(a.name, 'Ativo') as name, 
               COALESCE(ac.color, '#6b7280') as color, 
               COALESCE(SUM(d.amount), 0) as total
        FROM dividends d 
        LEFT JOIN assets a ON d.asset_id = a.id
        LEFT JOIN asset_classes ac ON a.asset_class_id = ac.id
        WHERE d.user_id = $1 AND EXTRACT(YEAR FROM d.payment_date) = $2
        GROUP BY a.id, a.ticker, a.name, ac.color
        ORDER BY total DESC
      `, [userId, targetYear]);

      const totalInvestedResult = await pool.query(`
        SELECT COALESCE(SUM(quantity * average_price), 0) as total 
        FROM assets 
        WHERE user_id = $1 AND quantity > 0
      `, [userId]);

      const totalYear = parseFloat(totalYearResult.rows[0]?.total || 0);
      const thisMonth = parseFloat(thisMonthResult.rows[0]?.total || 0);
      const invested = parseFloat(totalInvestedResult.rows[0]?.total || 0);
      const yieldOnCost = invested > 0 ? (totalYear / invested) * 100 : 0;

      return res.json({
        totalYear,
        thisMonth,
        avgMonthly: totalYear / 12,
        byMonth: byMonthResult.rows,
        byAsset: byAssetResult.rows,
        yieldOnCost: Math.round(yieldOnCost * 100) / 100
      });
    } catch (error) {
      console.error('Erro ao obter resumo:', error);
      return res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }

  async create(req, res) {
    try {
      const userId = req.userId;
      const { assetId, type, amount, paymentDate, exDate, notes } = req.body;

      if (!assetId || !amount || !paymentDate) {
        return res.status(400).json({ error: 'Campos obrigatórios: assetId, amount, paymentDate' });
      }

      const assetCheck = await pool.query(
        'SELECT id FROM assets WHERE id = $1 AND user_id = $2',
        [assetId, userId]
      );
      
      if (assetCheck.rows.length === 0) {
        return res.status(404).json({ error: 'Ativo não encontrado' });
      }

      const result = await pool.query(`
        INSERT INTO dividends (user_id, asset_id, type, amount, payment_date, ex_date, notes)
        VALUES ($1, $2, $3, $4, $5, $6, $7)
        RETURNING *
      `, [userId, assetId, type || 'DIVIDEND', amount, paymentDate, exDate || null, notes || null]);

      return res.status(201).json({ dividend: result.rows[0] });
    } catch (error) {
      console.error('Erro ao criar dividendo:', error);
      return res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }

  async update(req, res) {
    try {
      const userId = req.userId;
      const { id } = req.params;
      const { type, amount, paymentDate, exDate, notes } = req.body;

      const result = await pool.query(`
        UPDATE dividends SET
          type = COALESCE($1, type),
          amount = COALESCE($2, amount),
          payment_date = COALESCE($3, payment_date),
          ex_date = COALESCE($4, ex_date),
          notes = COALESCE($5, notes)
        WHERE id = $6 AND user_id = $7
        RETURNING *
      `, [type, amount, paymentDate, exDate, notes, id, userId]);

      if (result.rows.length === 0) {
        return res.status(404).json({ error: 'Dividendo não encontrado' });
      }
      
      return res.json({ dividend: result.rows[0] });
    } catch (error) {
      console.error('Erro ao atualizar dividendo:', error);
      return res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }

  async delete(req, res) {
    try {
      const userId = req.userId;
      const { id } = req.params;

      const result = await pool.query(
        'DELETE FROM dividends WHERE id = $1 AND user_id = $2 RETURNING id',
        [id, userId]
      );

      if (result.rows.length === 0) {
        return res.status(404).json({ error: 'Dividendo não encontrado' });
      }
      
      return res.json({ message: 'Dividendo excluído' });
    } catch (error) {
      console.error('Erro ao excluir dividendo:', error);
      return res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
}

module.exports = new DividendsController();